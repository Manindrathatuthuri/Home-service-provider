const express=require("express");
const route=express.Router();

const list=require("../models/listing.js");
const warpAsync=require("../util/warpasync.js");
const {validatelist}=require("../views/middleware.js");
const { isLoggedin,isowner } = require("../views/middleware.js");
const listingcontroller=require("../controller/lists.js");
const multer  = require('multer')
const {storage}=require("../cloudconfig.js")
const upload = multer({ storage})





// const validatelist=( req,res,next)=>{
//     let result=listschema.validate(req.body);
//     console.log(result);
//     if(result.error){
//          throw new ExpressError(404, result.error);     
//     }else{
//         next();
//     }
// }


// route.get("/",(req,res)=>{
//     res.send("hi welcome");
// })

// index route


route.route("/list")
.get(  warpAsync(listingcontroller.index))
.post( upload.single('list[image]'),validatelist,warpAsync(listingcontroller.addingnewlist));


//create route
route.get("/list/new", isLoggedin,(listingcontroller.newlistcr));

// adding new list route
// route.post("/list", validatelist,warpAsync(listingcontroller.addingnewlist));


// //create route
// route.get("/list/new",(req,res,next)=>{
//     res.render("from.ejs");


// })


// editing route
route.get("/list/:id/edit",isLoggedin,isowner, warpAsync(listingcontroller.editlist));

// show route

route.route("/list/:id")
    .get(   warpAsync(listingcontroller.showlist)) 
    .put(  upload.single('list[image]'),validatelist,warpAsync(listingcontroller.addeditlist))
    .delete(   isLoggedin, isowner,warpAsync(listingcontroller.deletelist ));



// route.get("/list/:id",   warpAsync(listingcontroller.showlist));
// route.put("/list/:id",   validatelist,warpAsync(listingcontroller.addeditlist));
// //delete route
// route.delete("/list/:id",   isLoggedin, isowner,warpAsync(listingcontroller.deletelist ));


module.exports=route;
