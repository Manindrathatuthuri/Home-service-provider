const express=require("express");
const route=express.Router();

const list=require("../models/listing.js")
const warpAsync=require("../util/warpasync.js");
const ExpressError=require("../util/ExpressError.js");
const {listschema,reviewschema}=require("../schema.js");
const review=require("../models/review.js");
const { isLoggedin ,isauthor} = require("../views/middleware.js");
const reviewController=require("../controller/reviews.js");


const validatereview=( req,res,next)=>{
    let result=reviewschema.validate(req.body);
    console.log(result);
    if(result.error){
         throw new ExpressError(404, result.error);     
    }else{
        next();
    }
}


route.post("/list/:id/reviews" 
    ,isLoggedin, 
    validatereview 
    ,warpAsync(reviewController.createReview));


    
//reviw delete route
route.delete("/list/:id/reviews/:reviewsId",
  isLoggedin,
   isauthor, 
   warpAsync(reviewController.deleteReview));


module.exports=route;