const list=require("../models/listing.js");
const review=require("../models/review.js");


module.exports.createReview=async (req,res)=>{

    let{id}=req.params;
    let lists= await list.findById(req.params.id);
    console.log(lists);
    let newreview=  await new review(req.body.review)
    newreview.save();
    newreview.author= req.user._id;
    console.log(newreview);
   await lists.reviews.push(newreview);

    await lists.save();
    console.log("review saved");
    req.flash("success","New Review is created ");
    res.redirect(`/list/${id}`);

}


module.exports.deleteReview=async(req,res)=>{
     let{id ,reviewsId}=req.params;
     await list.findByIdAndUpdate(id,{$pull:{reviews:reviewsId}});
     await review.findByIdAndDelete(reviewsId);
     req.flash("success","Review is Deleted");
     res.redirect(`/list/${id}`);



}