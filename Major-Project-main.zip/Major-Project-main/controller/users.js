const User=require("../models/user.js");
const passport=require("passport");
const {saveredirectUrl}= require("../views/middleware.js");





module.exports.fromsubmit=async(req,res)=>{
    try{
      let{username, email, password}=req.body;
      let newuser= new User({ username,email});
         const registerduser=  await User.register(newuser,password);
         console.log(registerduser);
         // req.login(registerduser,(err)=>{
         //     if(err){
         //       return next(err);
         //     }
         //     req.flash("success , welcome to the wonderlust");
         //     res.redirect("/list");
         // })
         req.flash("success , welcome to the wonderlust");
         res.redirect("/list");
   
     } catch(e){
           req.flash("error",e.message);
           res.redirect("/signup");
       }
   
     }

module.exports.loginform=(req,res)=>{
    res.render("login.ejs");
  }

module.exports.loginsubmit= passport.authenticate("local",
    {failureredirect:'/login',failureflash:true}),
    async  (req,res)=>{
     req.flash("success","welcome to wanderlust");
     let redirectUrl= res.locals.redirectUrl || "/list";
     res.redirect(redirectUrl);
}

module.exports.logoutform=(req,res,next)=>{
    req.logout((err) =>{
          if (err){
            return  next(err);
          }
          req.flash("success","you are logged out");
          res.redirect("/list");
    })

  }