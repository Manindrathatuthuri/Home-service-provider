const list=require("../models/listing.js")

module.exports.index=async(req,res,next)=>{
    const allList=  await list.find({});
   res.render("index.ejs",{allList});

}

module.exports.newlistcr=(req,res,next)=>{
    //  if(!req.isAuthenticated()){
    //     req.flash("error"," you have to login");
    //     res.redirect("/login");
    //  }
        
        res.render("from.ejs");
    }
 module.exports.addingnewlist=async(req,res,next)=>{
    let url=req.file.path;
    let filename=req.file.filename;
    let newlist= new list(req.body.list);
    newlist.owner= req.user._id;
    newlist.image={url,filename}
      await newlist.save();
    req.flash("success","New Listing is Added");
    res.redirect("/list");
}

module.exports.editlist=async (req,res,next)=>{
    let {id}=req.params;
    let  lists= await list.findById(id);
    if(!lists){
        req.flash("error","Listing you requested for does not Exit");
        res.redirect("/list");
    }
    res.render("edit.ejs",{lists});

}
module.exports.showlist=async (req,res,next)=>{
    let {id}=req.params;
    let  lists= await list.findById(id).populate({path:"reviews",
       populate:{path:"author"}}).populate("owner");
    if(!lists){
       req.flash("error","Listing you requested for does not Exit");
       res.redirect("/list");
   }
    res .render("show.ejs",{lists})
    
}


module.exports.addeditlist=async(req,res,next)=>{
    let {id}=req.params;
    let listing= await list.findByIdAndUpdate(id,{...req.body.list})
    if(typeof req.file!=="undefined"){
     let url=req.file.path;
     let filename=req.file.filename;
     listing.image={url,filename};
     await listing.save()
    }
     req.flash("success","List is updated");
    res.redirect("/list");
}

module.exports.deletelist=async (req,res,next)=>{

    let{id}=req.params;
    await list.findByIdAndDelete(id);
    req.flash("success"," Listing  is Deleted");
    res.redirect("/list");
   
}