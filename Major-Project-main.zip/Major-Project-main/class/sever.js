const  express=require("express");
const app=express();
const session=require("express-session");



 const cookieParser=require("cookie-parser");


app.use(session({secret:" supersecret",
    resave:false, 
    saveUninitialized: true}));

 app.use(cookieParser());

app.listen("3000",(req,res)=>{
    console.log("sever is listening");
})

app.get("/register",(req,res)=>{
    let{name="anoymas"}=req.query;
    req.session.name=name;
    console.log(req.session);
    res.redirect("/hello");
})

app.get("/hello",(req,res)=>{
    
    res.send(`hello${req.session.name}`);
})
// app.get("/sessioncount",(req,res)=>{

// if( req.session.count){
//     req.session.count++;
// }else{
//     req.session.count=1; 
// }
   
//     res.send(` the request is sent ${req.session.count}`);
// })


// app.get("/getcookie",(req,res)=>{
//     res.cookie("vishnu","hahaha")
//     res.send("cookie");
// });
// app.get("/greet",(req,res)=>{
//     let{name="anonams"}=req.cookies;
//     res.send(`hi${name}`);
// })
// app.get("/user",(req,res)=>{
//     console.dir(req.cookies);
//     res.send("user reqest");
// })
// app.post("/user",(req,res)=>{
//     res.send("user request");
// })
// app.get("/user/:id",(req,res)=>{
//     res.send("show page request");
// })

