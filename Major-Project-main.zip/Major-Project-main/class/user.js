const express=require("express");
const router=express.Router();


router.get("/user",(req,res)=>{
    res.send("user reqest");
})
router.post("/user",(req,res)=>{
    res.send("user request");
})
router.get("/user/:id",(req,res)=>{
    res.send("show page request");
})


module.exports=router;

