const mongoose=require("mongoose");
const review=require("./review.js");
const user= require("./user.js");

const  listschema = new mongoose.Schema ({
    title:{
        type:String,
        requried:true
    },
    description:String,
    image: {
      filename:String,
       url:String,

      },

    price:{
      type:String,
      requried:true
  },
    location:{
      type:String,
      requried:true
  },
    country:{
      type:String,
      requried:true
  },
  reviews:[
    {
      type: mongoose.Schema.Types.ObjectId,
      ref:"review"
    }
  ],
  owner:
    {
      type:mongoose.Schema.Types.ObjectId,
      ref:"User"
    },
 
  
  


});

listschema.post("findOneAndDelete",async(list)=>{
  await review.deleteMany({_id:{$in:list.reviews}});
});

const list=mongoose.model("list",listschema);

module.exports=list;