if(process.env.NODE_ENV!="production"){
    require('dotenv').config()
}

const express=require("express");
const app=express();
const mongoose= require("mongoose");
const methodOverride=require("method-override");
const path= require("path");
const ejsmate=require("ejs-mate");
const ExpressError=require("./util/ExpressError.js");

const listing=require("./router/list.js");
const reviews=require("./router/review.js");
const userr=require("./router/userr.js");

const session =require("express-session");
const flash=require("connect-flash");
const User=require("./models/user.js");
const passport=require("passport")
const LocalStratagey=require("passport-local");

app.set("view engine","ejs");
app.set("views" ,path.join(__dirname,"views"))
app.use(express.urlencoded({extended:true}))
app.use(methodOverride("_method") );
app.engine("ejs",ejsmate);
app.use(express.static(path.join(__dirname,"/public")));


const sessionoption={
    secret:"topsecrect",
    resave:false,
    saveUninitialized:true,
    cookie:{
        expire:Date.now()+7*24*60*60*1000,
        maxAge:7*24*60*60*1000,
        httpOnly:true
    }

}
main() 
.then(()=>{
    console.log("connection successfull")
})
.catch((err)=>{
    console.log(err);
})

app.use(session(sessionoption));
app.use(flash())
app.use(passport.initialize());
app.use(passport.session());
passport.use(new LocalStratagey(User.authenticate()))

passport.serializeUser(User.serializeUser());
passport.deserializeUser(User.deserializeUser());


async function main(){
await mongoose.connect('mongodb://127.0.0.1:27017/wanderlust');
}

 




app.use((req,res,next)=>{
    res.locals.success=req.flash("success");
    res.locals.error=req.flash("error");
    res.locals.curruser=req.user;
    next();
})

app.get("/home", (req, res) => {
    res.sendFile(path.join(__dirname, "public", "index-1.html"));
});

   app.use("/",listing) 
   app.use("/",reviews)
   app.use("/",userr);

  

// app.use("/demo", async(req,res)=>{
//        let fakeuser4= new User({
//         email:"ksaimadhukiran@gmail.com",
//         username:"oisfjoanf"

//        })

//       let useri=await User.register(fakeuser4,"helloword");
//       res.send(useri);
// })

app.all("*",(req,res,next)=>{
    next(new ExpressError(404,"page not found"));
});
app.use((err,req,res,next )=>{
    let{status=500, message=" hi "}=err;
     res.render("error.ejs",{err});
   })


app.listen(4000,(req,res)=>{
    console.log("sever is listening")
})

