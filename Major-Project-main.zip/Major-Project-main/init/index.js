const mongoose= require("mongoose");
const initdata=require("./data.js");
const list=require("../models/listing.js");

main() 
.then(()=>{
    console.log("connection successfull")
})
.catch((err)=>{
    console.log(err);
})


async function main(){
await mongoose.connect('mongodb://127.0.0.1:27017/wanderlust');
}


 const initdb= async ()=>{
    await list.deleteMany({});
    initdata.data= initdata.data.map((obj)=>({...obj,owner:'66af14b1a846142b3c0979c3'}))
    await list.insertMany(initdata.data)
    console.log("data was successfully inserted")
 }
 

 initdb();