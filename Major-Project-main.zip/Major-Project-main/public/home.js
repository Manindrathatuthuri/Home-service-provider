const services = [
    { id: 1, imageUrl: '/Photos/hclean.jpg', name: 'Home Cleaning', description: 'Full home cleaning service' },
    { id: 2, imageUrl: '/Photos/ac clean.jpg', name: 'AC Repair', description: 'Air conditioner repair service' },
    { id: 3, imageUrl: '/Photos/hpb.jpg', name: 'Plumbing', description: 'Fixing leaks and pipes' },
    { id: 4, imageUrl: '/Photos/hele.jpeg', name: 'Electrical Work', description: 'Fixing electrical issues' },
    { id: 5, imageUrl: '/Photos/hcook.jpeg', name: 'Cooking', description: 'Cooking any type of dishes' },
    { id: 6, imageUrl: '/Photos/hla.jpeg', name: 'Laundry', description: 'Washing clothes' },
    { id: 7, imageUrl: '/Photos/makeup.jpg', name: 'Beauty', description: 'Makeup' },
    { id: 8, imageUrl: '/Photos/hs.jpeg', name: "Men's Salon", description: 'Any style' },
    { id: 9, imageUrl: '/Photos/hp.jpeg', name: 'Painting', description: 'Any design' }
];

// Function to display services
function displayServices() {
    const serviceList = document.getElementById('service-list');
    serviceList.innerHTML = ''; // Clear the container before adding new elements

    services.forEach(service => {
        const serviceCard = `
            <div class="col-md-4">
                <div class="card mb-4">
                    <img src="${service.imageUrl}" class="card-img-top" alt="${service.name}">
                    <div class="card-body">
                        <h5 class="card-title">${service.name}</h5>
                        <p class="card-text">${service.description}</p>
                    </div>
                </div>
            </div>
        `;
        serviceList.innerHTML += serviceCard;
    });
}

// Initialize services on page load
window.onload = displayServices;
