const ExpressError=require("../util/ExpressError.js");
const {listschema}=require("../schema.js");

const list=require("../models/listing.js");

const reviews=require("../models/review.js")

module.exports.isLoggedin = (req,res,next)=>{
    if(!req.isAuthenticated()){
        req.session.redirectUrl= req.originalUrl;
        req.flash("error"," you have to login");
        return res.redirect("/login");
        
     }
     next();
}

module.exports.saveredirectUrl=(req,res,next)=>{
    if(req.session.redirectUrl){
    res.locals.redirectUrl=req.session.redirectUrl;
    }
    next();
}

module.exports.isowner= async(req,res,next)=>{
    let {id}=req.params;
    let lists= await list.findById(id);
    if(!lists.owner._id.equals(res.locals.curruser._id)){
        req.flash("error"," you are not allowed  to do changes");
         return res.redirect(`/list/${id}`);
    }
    next();
}

module.exports.validatelist=( req,res,next)=>{
    let result=listschema.validate(req.body);
    console.log(result);
    if(result.error){
         throw new ExpressError(404, result.error);     
    }else{
        next();
    }
}


module.exports.isauthor= async(req,res,next)=>{
    let { id,reviewsId}=req.params;
    let review= await  reviews.findById(reviewsId);
    if(!review.author._id.equals(res.locals.curruser._id)){
        req.flash("error","you are  unable to delete it");
         return res.redirect(`/list/${id}`);
    }
    next();
}